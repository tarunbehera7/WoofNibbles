package com.example.woofnibbles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WoofNibblesApplicationTests {

	@Test
	void contextLoads() {
	}

}
